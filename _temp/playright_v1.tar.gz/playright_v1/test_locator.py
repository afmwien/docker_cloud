"""
Test-Skript für ImageLocator

2-Phasen Ansatz:
1. Schnelle Lokalisierung durch Scrollen (ohne Screenshots)
2. Ein optimaler Screenshot mit Zoom-Anpassung
"""

import logging
import subprocess
from pathlib import Path

# Logging konfigurieren
logger = logging.getLogger()
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S"
    ))
    logger.addHandler(handler)

from src import PageCleaner, PageCleanerConfig
from src.image_matcher import ImageLocator


def main():
    # Konfiguration
    page_config = PageCleanerConfig(
        profile_dir=Path("data/chrome_profile"),
        headless=False,
        max_cleaning_loops=3,
        screenshot_dir=Path("output/screenshots"),
        reload_after_cleaning=False,
    )

    reference_image = Path("data/reference_images/thermenwartung-2048x1366.png")
    url = "https://www.thermen-installateur.at/"
    output_path = Path("output/screenshots/thermen_optimal.png")

    print("=" * 60)
    print("IMAGE LOCATOR TEST")
    print("2-Phasen: Lokalisierung + Optimaler Screenshot")
    print("=" * 60)
    print(f"URL: {url}")
    print(f"Referenzbild: {reference_image}")
    print(f"Output: {output_path}")
    print()

    if not reference_image.exists():
        print(f"FEHLER: Referenzbild nicht gefunden: {reference_image}")
        return

    with PageCleaner(page_config) as cleaner:
        # Seite laden
        print("Lade Seite...")
        cleaner._page.goto(url, wait_until="networkidle", timeout=30000)
        cleaner._page.wait_for_timeout(2000)

        print(f"Titel: {cleaner._page.title()}")
        print()

        # ImageLocator erstellen
        locator = ImageLocator(cleaner._page)

        # Bild finden und optimalen Screenshot erstellen
        result = locator.find_and_screenshot(
            reference_image=reference_image,
            output_path=output_path,
            context_pixels=150,  # 150px Kontext oben/unten
            min_zoom=0.5,        # Mindestens 50% Zoom
            max_zoom=1.0,        # Maximal 100% Zoom
        )

        print()
        print("=" * 60)
        print("ERGEBNIS")
        print("=" * 60)
        print(f"Erfolg: {result.success}")

        if result.location:
            loc = result.location
            print(f"Bild gefunden: {loc.found}")
            print(f"Position: X={loc.x}, Y={loc.y}")
            print(f"Größe: {loc.width}x{loc.height}")
            print(f"Confidence: {loc.confidence:.1%}")
            print(f"Methode: {loc.method}")

        if result.success:
            print(f"Zoom-Level: {result.zoom_level:.0%}")
            print(f"Scroll-Position: {result.scroll_position}")
            print(f"Screenshot: {result.screenshot_path}")

            # Screenshot öffnen
            subprocess.Popen(["start", "", str(output_path)], shell=True)

        if result.error:
            print(f"Fehler: {result.error}")

    print()
    print("=" * 60)
    print("FERTIG")
    print("=" * 60)


if __name__ == "__main__":
    main()
