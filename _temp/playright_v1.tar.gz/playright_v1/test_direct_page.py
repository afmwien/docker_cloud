"""Test: Direkter Zugriff auf die Erlebnisbad-Seite"""

import sys
sys.path.insert(0, 'src')

from playwright.sync_api import sync_playwright
from image_matcher.image_locator import ImageLocator
from pathlib import Path

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    page = browser.new_page()

    # Direkt zur richtigen Seite
    print("Lade Seite...")
    page.goto('https://www.muehlviertel.at/oesterreich-poi/detail/200216/erlebnisbad-lagune-pregarten.html', timeout=30000)
    page.wait_for_timeout(2000)

    locator = ImageLocator(page)

    # Bild suchen
    print("Suche Bild...")
    result = locator.find_and_screenshot(
        reference_image=Path('data/reference_images/pregarten.jpg'),
        output_path=Path('output/screenshots/pregarten_correct.png')
    )

    print('=' * 60)
    print('ERGEBNIS')
    print('=' * 60)
    print(f"Erfolg: {result.success}")

    if result.location and result.location.found:
        loc = result.location
        print(f"Confidence: {loc.confidence:.1%}")
        print(f"Methode: {loc.method}")
        print(f"Position: {loc.x}, {loc.y}")
        print(f"Größe: {loc.width}x{loc.height}")
        if loc.src:
            src_display = loc.src[:80] + "..." if len(loc.src) > 80 else loc.src
            print(f"URL: {src_display}")
        print(f"Screenshot: {result.screenshot_path}")
        print(f"Zoom: {result.zoom_level:.0%}")
    else:
        print(f"Fehler: {result.error}")
print("\nFERTIG")
