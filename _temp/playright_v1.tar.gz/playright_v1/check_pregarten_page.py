"""Prüft alle Bilder auf der Pregarten-Seite"""

from playwright.sync_api import sync_playwright
from PIL import Image
import imagehash
import requests
from io import BytesIO
from pathlib import Path

ref_img = Image.open('data/reference_images/pregarten.jpg')
ref_hash = imagehash.phash(ref_img, hash_size=16)
print(f'Referenz: {ref_img.size}, Hash: {str(ref_hash)[:30]}...')
print()

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    page.goto('https://www.muehlviertel.at/unsere-region/unsere-gemeinden/pregarten.html', timeout=30000)
    page.wait_for_timeout(2000)

    # Alle Bilder mit srcset
    images = page.evaluate("""() => {
        const result = [];
        document.querySelectorAll('img').forEach(img => {
            const entry = {
                src: img.currentSrc || img.src,
                srcset: img.srcset || '',
                width: img.naturalWidth,
                height: img.naturalHeight
            };
            if (entry.src && !entry.src.startsWith('data:')) {
                result.push(entry);
            }
        });
        return result;
    }""")

    print(f'{len(images)} Bilder auf der Pregarten-Seite')
    print()

    best_match = None
    best_distance = 999

    for img in images:
        # Alle URLs aus srcset parsen
        urls = [img['src']]
        if img['srcset']:
            for part in img['srcset'].split(','):
                url = part.strip().split()[0]
                if url:
                    urls.append(url)

        for url in urls:
            try:
                resp = requests.get(url, timeout=10, headers={'User-Agent': 'Mozilla/5.0'})
                if resp.status_code == 200:
                    found = Image.open(BytesIO(resp.content))
                    h = imagehash.phash(found, hash_size=16)
                    dist = ref_hash - h
                    sim = 1 - dist / 256

                    print(f'Bild: {found.size}, Distanz: {dist}, Sim: {sim:.1%}')
                    print(f'  {url[:80]}')

                    if dist < best_distance:
                        best_distance = dist
                        best_match = {'url': url, 'size': found.size, 'dist': dist}

                    if dist <= 15:
                        print('  >>> EXACT MATCH! <<<')
            except Exception as e:
                print(f'Fehler: {e}')

    print()
    print('=' * 60)
    print(f'Bester Match: Distanz={best_distance}')
    if best_match:
        print(f'URL: {best_match["url"]}')
        print(f'Größe: {best_match["size"]}')

    browser.close()
