"""
Debug-Skript: Sucht nach Pregarten auf muehlviertel.at
"""

from pathlib import Path
from playwright.sync_api import sync_playwright

def main():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()

        # Startseite laden
        page.goto("https://www.muehlviertel.at/")
        page.wait_for_timeout(3000)

        # Nach Pregarten suchen
        print("Suche nach 'Pregarten' auf der Seite...")

        # Alle Links, die Pregarten enthalten
        links = page.evaluate("""
            () => {
                const links = [];
                document.querySelectorAll('a').forEach(a => {
                    const href = a.href || '';
                    const text = a.textContent || '';
                    if (href.toLowerCase().includes('pregarten') ||
                        text.toLowerCase().includes('pregarten')) {
                        links.push({href, text: text.trim().slice(0, 50)});
                    }
                });
                return links;
            }
        """)

        print(f"Gefundene Pregarten-Links: {len(links)}")
        for link in links:
            print(f"  - {link['text']}: {link['href']}")

        # Alle Bilder auf der Seite
        print("\nAlle Bild-URLs auf der Startseite:")
        images = page.evaluate("""
            () => {
                return Array.from(document.querySelectorAll('img'))
                    .map(img => img.src)
                    .filter(src => src && !src.startsWith('data:'));
            }
        """)

        for img in images[:15]:
            print(f"  - {img}")

        if len(images) > 15:
            print(f"  ... und {len(images) - 15} weitere")

        browser.close()

if __name__ == "__main__":
    main()
