"""
Test-Skript für Image Matching

Testet die Suche nach thermenwartung auf thermen-installateur.at
mit Full-Page Screenshot
"""

import logging
from pathlib import Path

# Logging konfigurieren
logger = logging.getLogger()
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S"
    ))
    logger.addHandler(handler)

from src import PageCleaner, PageCleanerConfig
from src.image_matcher import ImageMatcher, ImageMatchConfig, TemplateMatcher
from src.screenshot import ScreenshotManager, ScreenshotConfig


def main():
    # Konfiguration
    page_config = PageCleanerConfig(
        profile_dir=Path("data/chrome_profile"),
        headless=False,
        max_cleaning_loops=3,
        include_browser_ui=False,  # Wir machen Full-Page Screenshot separat
        screenshot_dir=Path("output/screenshots"),
        reload_after_cleaning=False,
    )

    reference_image = Path("data/reference_images/thermenwartung-2048x1366.png")
    url = "https://www.thermen-installateur.at/"

    print("=" * 60)
    print("IMAGE MATCHER TEST - FULL PAGE MIT URL-LEISTE")
    print("=" * 60)
    print(f"URL: {url}")
    print(f"Referenzbild: {reference_image}")
    print()

    if not reference_image.exists():
        print(f"FEHLER: Referenzbild nicht gefunden: {reference_image}")
        return

    with PageCleaner(page_config) as cleaner:
        # Seite laden (der Context Manager startet den Browser bereits)
        print("Lade Seite...")

        cleaner._page.goto(url, wait_until="networkidle", timeout=30000)
        cleaner._page.wait_for_timeout(3000)

        print(f"Titel: {cleaner._page.title()}")

        # Full-Page Screenshot erstellen MIT Browser-UI (URL-Leiste + Taskleiste)
        print("\nErstelle Full-Page Desktop-Screenshot (mit URL-Leiste)...")
        screenshot_mgr = ScreenshotManager(
            cleaner._page,
            ScreenshotConfig(output_dir=Path("output/screenshots"))
        )

        # Scrolling Desktop Screenshot (mit Browser-UI)
        result = screenshot_mgr.capture_scrolling_desktop(
            "thermen_fullpage_desktop.png",
            scroll_step=700,  # Pixel pro Scroll
            max_height=15000,  # Max Gesamthöhe
            overlap=150  # Überlappung für besseres Stitching
        )

        if not result.success:
            print(f"Screenshot Fehler: {result.error}")
            return

        print(f"Full-Page Screenshot: {result.filepath}")
        print(f"Größe: {result.width}x{result.height}")

        # Template Matching auf Full-Page Screenshot
        print("\n" + "-" * 40)
        print("Template-Matching auf Full-Page Screenshot...")
        print("-" * 40)

        template_matcher = TemplateMatcher(threshold=0.6)

        match_result = template_matcher.find_multi_scale(
            reference_image,
            result.filepath,
            scales=[0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
        )

        print()
        print("=" * 40)
        print("ERGEBNIS")
        print("=" * 40)
        print(f"Gefunden: {match_result.found}")
        print(f"Confidence: {match_result.confidence:.1%}")
        print(f"Scale: {match_result.scale}")

        if match_result.bounding_box:
            bb = match_result.bounding_box
            print(f"Position: x={bb.x}, y={bb.y}")
            print(f"Größe im Screenshot: {bb.width}x{bb.height}")

            # Highlight erstellen
            highlight_path = Path("output/screenshots/thermen_desktop_highlighted.png")
            template_matcher.highlight_match(
                match_result,
                result.filepath,
                highlight_path,
                color=(0, 255, 0),
                thickness=5
            )
            print(f"Markierter Screenshot: {highlight_path}")

            # Öffnen
            import subprocess
            subprocess.Popen(["start", "", str(highlight_path)], shell=True)

    print()
    print("=" * 60)
    print("FERTIG")
    print("=" * 60)


if __name__ == "__main__":
    main()
