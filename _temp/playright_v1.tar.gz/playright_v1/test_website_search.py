"""
Test-Skript für Website-weite Bildsuche

Durchsucht die gesamte Website nach dem Referenzbild.
"""

import logging
import subprocess
from pathlib import Path

# Logging konfigurieren
logger = logging.getLogger()
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S"
    ))
    logger.addHandler(handler)

from src import PageCleaner, PageCleanerConfig
from src.image_matcher import ImageLocator


def main():
    # Konfiguration
    page_config = PageCleanerConfig(
        profile_dir=Path("data/chrome_profile"),
        headless=False,
        screenshot_dir=Path("output/screenshots"),
    )

    # Test mit muehlviertel.at und pregarten.jpg
    reference_image = Path("data/reference_images/pregarten.jpg")
    base_url = "https://www.muehlviertel.at/"
    output_path = Path("output/screenshots/pregarten_found.png")

    print("=" * 60)
    print("WEBSITE-WEITE BILDSUCHE")
    print("=" * 60)
    print(f"Website: {base_url}")
    print(f"Referenzbild: {reference_image}")
    print(f"Output: {output_path}")
    print()

    if not reference_image.exists():
        print(f"FEHLER: Referenzbild nicht gefunden: {reference_image}")
        return

    with PageCleaner(page_config) as cleaner:
        # ImageLocator erstellen
        locator = ImageLocator(cleaner._page)

        # Website durchsuchen
        result = locator.find_on_website(
            reference_image=reference_image,
            output_path=output_path,
            base_url=base_url,
            max_pages=30,          # Max 30 Seiten durchsuchen
            context_pixels=150,
        )

        print()
        print("=" * 60)
        print("ERGEBNIS")
        print("=" * 60)
        print(f"Erfolg: {result.success}")

        if result.location:
            loc = result.location
            print(f"Bild gefunden: {loc.found}")
            print(f"Position: X={loc.x}, Y={loc.y}")
            print(f"Größe: {loc.width}x{loc.height}")
            print(f"Confidence: {loc.confidence:.1%}")
            print(f"Methode: {loc.method}")
            print(f"Bild-URL: {loc.src[:80]}...")

        if result.success:
            print(f"Zoom-Level: {result.zoom_level:.0%}")
            print(f"Screenshot: {result.screenshot_path}")

            # Screenshot öffnen
            subprocess.Popen(["start", "", str(output_path)], shell=True)

        if result.error:
            print(f"Fehler: {result.error}")

    print()
    print("=" * 60)
    print("FERTIG")
    print("=" * 60)


if __name__ == "__main__":
    main()
