"""
Test für den Cookie Handler mit der Thermen-Installateur Seite
"""
import sys
sys.path.insert(0, ".")

from playwright.sync_api import sync_playwright
from src.cookie_handler import CookieHandler, CookieHandlerConfig


def test_cookie_handler():
    print("=" * 60)
    print("COOKIE HANDLER TEST")
    print("=" * 60)

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page(viewport={"width": 1280, "height": 720})

        # Konfiguration
        config = CookieHandlerConfig(
            detection_timeout_ms=5000,
            click_timeout_ms=3000,
            retry_attempts=3,
            check_shadow_dom=True,
            check_iframes=True,
            save_storage_state=True,
            take_debug_screenshots=True,
        )

        # Seite laden
        url = "https://www.thermen-installateur.at/"
        print(f"\nLade: {url}")
        page.goto(url, wait_until="domcontentloaded")

        # Screenshot vorher
        page.screenshot(path="output/screenshots/before_consent.png")
        print("Screenshot vorher: output/screenshots/before_consent.png")

        # Cookie Handler ausführen
        print("\n--- Cookie Handler startet ---")
        handler = CookieHandler(page, config)
        result = handler.handle_consent()

        # Ergebnis ausgeben
        print("\n--- ERGEBNIS ---")
        print(f"Erfolgreich:     {result.success}")
        print(f"Banner gefunden: {result.banner_found}")
        print(f"CMP erkannt:     {result.cmp_detected}")
        print(f"Methode:         {result.method_used}")
        print(f"Selektor:        {result.selector_used}")
        print(f"Aktion:          {result.action_taken}")
        print(f"Dauer:           {result.duration_ms:.0f}ms")
        print(f"Cookies vorher:  {result.cookies_before}")
        print(f"Cookies nachher: {result.cookies_after}")

        if result.error:
            print(f"Fehler:          {result.error}")

        # Screenshot nachher
        page.wait_for_timeout(1000)
        page.screenshot(path="output/screenshots/after_consent.png")
        print("\nScreenshot nachher: output/screenshots/after_consent.png")

        # Cookies anzeigen
        cookies = handler.get_current_cookies()
        print(f"\n--- COOKIES ({len(cookies)}) ---")
        for cookie in cookies[:10]:  # Max 10 anzeigen
            print(f"  {cookie['name']}: {cookie['value'][:50]}...")

        browser.close()

        print("\n" + "=" * 60)
        print("TEST ABGESCHLOSSEN")
        print("=" * 60)

        return result.success


if __name__ == "__main__":
    success = test_cookie_handler()
    sys.exit(0 if success else 1)
