"""
Chrome-Profil ins Projekt kopieren

Dieses Skript kopiert ein bestehendes Chrome-Profil ins Projekt,
damit die Cookies und Einstellungen für alle Benutzer verfügbar sind.

WICHTIG: Chrome muss während des Kopierens GESCHLOSSEN sein!
"""

import shutil
import sys
from pathlib import Path

# Projekt-Root
PROJECT_ROOT = Path(__file__).parent
TARGET_DIR = PROJECT_ROOT / "data" / "chrome_profile"

# Dein Chrome-Profil Pfad
SOURCE_DIR = Path(r"C:\Users\User\AppData\Local\Google\Chrome\User Data")


def copy_chrome_profile():
    """Kopiert das Chrome-Profil ins Projekt."""

    print("=" * 60)
    print("CHROME-PROFIL KOPIEREN")
    print("=" * 60)

    print(f"\nQuelle:  {SOURCE_DIR}")
    print(f"Ziel:    {TARGET_DIR}")

    # Prüfen ob Quelle existiert
    if not SOURCE_DIR.exists():
        print(f"\n❌ FEHLER: Quell-Profil nicht gefunden!")
        print(f"   Bitte passe SOURCE_DIR in diesem Skript an.")
        return False

    # Warnung
    print("\n⚠️  WICHTIG:")
    print("   1. Schließe Chrome KOMPLETT (auch im System-Tray)")
    print("   2. Das Ziel-Verzeichnis wird überschrieben")

    input("\nDrücke ENTER um fortzufahren (oder Strg+C zum Abbrechen)...")

    # Ziel-Verzeichnis vorbereiten
    if TARGET_DIR.exists():
        print(f"\nLösche bestehendes Profil: {TARGET_DIR}")
        shutil.rmtree(TARGET_DIR)

    TARGET_DIR.mkdir(parents=True, exist_ok=True)

    # Nur relevante Dateien kopieren (nicht alles!)
    # Das reduziert die Größe erheblich
    relevant_items = [
        "Default",           # Hauptprofil mit Cookies
        "Local State",       # Verschlüsselungskeys
        "First Run",         # Marker
    ]

    # Optional: Weitere Profile (Profile 1, Profile 2, etc.)
    for item in SOURCE_DIR.iterdir():
        if item.name.startswith("Profile "):
            relevant_items.append(item.name)

    print(f"\nKopiere {len(relevant_items)} Elemente...")

    copied = 0
    for item_name in relevant_items:
        source_item = SOURCE_DIR / item_name
        target_item = TARGET_DIR / item_name

        if not source_item.exists():
            print(f"  ⚠️  Übersprungen (nicht gefunden): {item_name}")
            continue

        try:
            if source_item.is_dir():
                # Ordner kopieren (ohne Cache-Dateien)
                shutil.copytree(
                    source_item,
                    target_item,
                    ignore=shutil.ignore_patterns(
                        "Cache", "Code Cache", "GPUCache",
                        "Service Worker", "*.log", "*.tmp"
                    )
                )
            else:
                # Datei kopieren
                shutil.copy2(source_item, target_item)

            print(f"  ✓ {item_name}")
            copied += 1

        except PermissionError:
            print(f"  ❌ Keine Berechtigung: {item_name}")
            print("     → Ist Chrome wirklich geschlossen?")
        except Exception as e:
            print(f"  ❌ Fehler bei {item_name}: {e}")

    # Größe berechnen
    total_size = sum(
        f.stat().st_size for f in TARGET_DIR.rglob("*") if f.is_file()
    )
    size_mb = total_size / (1024 * 1024)

    print(f"\n{'=' * 60}")
    print("FERTIG!")
    print(f"{'=' * 60}")
    print(f"\nKopiert: {copied} Elemente")
    print(f"Größe:   {size_mb:.1f} MB")
    print(f"Pfad:    {TARGET_DIR}")

    print("\n📝 Nächste Schritte:")
    print("   1. Teste mit: python test_persistent_browser.py")
    print("   2. Die Cookies sollten jetzt verfügbar sein")

    return True


def show_profile_info():
    """Zeigt Informationen zum Projekt-Profil."""

    print("=" * 60)
    print("PROFIL-INFORMATION")
    print("=" * 60)

    if not TARGET_DIR.exists():
        print(f"\n❌ Kein Profil im Projekt gefunden.")
        print(f"   Pfad: {TARGET_DIR}")
        print(f"\n   Führe dieses Skript aus um eines zu kopieren.")
        return

    # Größe
    total_size = sum(
        f.stat().st_size for f in TARGET_DIR.rglob("*") if f.is_file()
    )
    size_mb = total_size / (1024 * 1024)

    # Cookies prüfen
    cookies_db = TARGET_DIR / "Default" / "Network" / "Cookies"
    has_cookies = cookies_db.exists()

    print(f"\nPfad:      {TARGET_DIR}")
    print(f"Größe:     {size_mb:.1f} MB")
    print(f"Cookies:   {'✓ Vorhanden' if has_cookies else '❌ Nicht gefunden'}")

    # Unterordner auflisten
    print(f"\nInhalt:")
    for item in sorted(TARGET_DIR.iterdir()):
        marker = "📁" if item.is_dir() else "📄"
        print(f"   {marker} {item.name}")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--info":
        show_profile_info()
    else:
        copy_chrome_profile()
