"""
Lädt Referenzbilder (Logos) von den Testseiten herunter.
"""
from playwright.sync_api import sync_playwright
from pathlib import Path


def download_reference_images():
    reference_dir = Path("data/reference_images")
    reference_dir.mkdir(parents=True, exist_ok=True)

    sites = [
        {
            "name": "Google",
            "url": "https://www.google.com",
            "filename": "google_logo.png",
            "selector": "img[alt='Google']"
        },
        {
            "name": "Wikipedia",
            "url": "https://www.wikipedia.org",
            "filename": "wikipedia_logo.png",
            "selector": ".central-featured-logo"
        },
        {
            "name": "GitHub",
            "url": "https://github.com",
            "filename": "github_logo.png",
            "selector": "svg.octicon-mark-github, .octicon-mark-github"
        }
    ]

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()

        for site in sites:
            print(f"Lade {site['name']}...")
            try:
                page.goto(site["url"], wait_until="networkidle")

                # Element finden und Screenshot davon machen
                element = page.locator(site["selector"]).first
                if element:
                    element.screenshot(path=str(reference_dir / site["filename"]))
                    print(f"  ✓ {site['filename']} gespeichert")
                else:
                    print(f"  ✗ Element nicht gefunden für {site['name']}")
            except Exception as e:
                print(f"  ✗ Fehler bei {site['name']}: {e}")

        browser.close()

    print("\nFertig! Referenzbilder in:", reference_dir.absolute())


if __name__ == "__main__":
    download_reference_images()
