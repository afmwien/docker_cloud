"""Debug: Warum matched der Hash nicht?"""

from playwright.sync_api import sync_playwright
from PIL import Image
import imagehash
import requests
from pathlib import Path
from io import BytesIO

# Referenzbild
ref_path = Path('data/reference_images/pregarten.jpg')
ref_img = Image.open(ref_path)
ref_hash = imagehash.phash(ref_img, hash_size=16)

print("=" * 60)
print("REFERENZBILD")
print("=" * 60)
print(f"Pfad: {ref_path}")
print(f"Größe: {ref_img.size}")
print(f"Mode: {ref_img.mode}")
print(f"pHash: {ref_hash}")

# Seite laden
print("\n" + "=" * 60)
print("BILDER AUF DER SEITE")
print("=" * 60)

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    page.goto('https://www.muehlviertel.at/en/food-drink/highenjoyment.html', timeout=30000)
    page.wait_for_timeout(2000)

    # Alle Bilder sammeln
    images = page.evaluate("""() => {
        return Array.from(document.querySelectorAll('img')).map(img => ({
            src: img.currentSrc || img.src,
            width: img.naturalWidth,
            height: img.naturalHeight
        })).filter(i => i.width > 100 && i.src && !i.src.startsWith('data:'));
    }""")

    print(f"\n{len(images)} Bilder gefunden\n")

    for i, img in enumerate(images):
        print(f"\n--- Bild {i+1}: {img['width']}x{img['height']} ---")
        url = img['src']
        print(f"URL: {url[:80]}..." if len(url) > 80 else f"URL: {url}")

        try:
            resp = requests.get(url, timeout=10, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0'
            })

            if resp.status_code == 200:
                # Direkt aus Memory laden statt Datei
                found_img = Image.open(BytesIO(resp.content))
                found_hash = imagehash.phash(found_img, hash_size=16)

                distance = ref_hash - found_hash
                similarity = 1 - (distance / 256)

                print(f"Download-Größe: {found_img.size}")
                print(f"pHash: {found_hash}")
                print(f"Hamming-Distanz: {distance}")
                print(f"Similarity: {similarity:.1%}")

                if distance <= 15:
                    print(">>> HASH MATCH! <<<")
                elif distance <= 40:
                    print(">>> Ähnlich <<<")

        except Exception as e:
            print(f"Fehler: {e}")

    browser.close()

print("\n" + "=" * 60)
print("FERTIG")
print("=" * 60)
