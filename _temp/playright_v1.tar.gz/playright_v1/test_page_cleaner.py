"""
Test-Skript für den Page Cleaner

Testet die komplette Pipeline:
1. Browser starten
2. Overlays entfernen
3. Sauberen Screenshot erstellen
"""

import logging
from pathlib import Path

# Logging konfigurieren (einmalig)
logger = logging.getLogger()
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S"
    ))
    logger.addHandler(handler)

from src import PageCleaner, PageCleanerConfig


def main():
    # Konfiguration
    config = PageCleanerConfig(
        profile_dir=Path("data/chrome_profile"),
        headless=False,
        max_cleaning_loops=5,
        include_browser_ui=True,
        screenshot_dir=Path("output/screenshots"),
    )

    # Test-URLs
    test_sites = [
        ("https://www.muehlviertel.at", "muehlviertel.png"),
        # ("https://www.thermen-installateur.at", "thermen.png"),
    ]

    print("=" * 60)
    print("PAGE CLEANER TEST")
    print("=" * 60)

    with PageCleaner(config) as cleaner:
        for url, filename in test_sites:
            print(f"\nTeste: {url}")
            print("-" * 40)

            result = cleaner.clean_and_screenshot(url, filename)

            print(f"\nErgebnis:")
            print(f"  Erfolg: {result.success}")
            print(f"  Titel: {result.title}")
            print(f"  Seite sauber: {result.page_is_clean}")

            if result.cleaning_result:
                print(f"  Overlays entfernt: {result.cleaning_result.overlays_removed}")
                print(f"  Cleaning-Loops: {result.cleaning_result.loops_needed}")

            if result.screenshot_path:
                print(f"  Screenshot: {result.screenshot_path}")

            if result.error:
                print(f"  Fehler: {result.error}")

            print(f"  Dauer: {result.total_duration_ms:.0f}ms")

    print("\n" + "=" * 60)
    print("FERTIG")
    print("=" * 60)


if __name__ == "__main__":
    main()
