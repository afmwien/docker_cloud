"""Sucht das Originalbild auf der Website - auch unprocessed Versionen"""

from playwright.sync_api import sync_playwright
from PIL import Image
import imagehash
import requests
from pathlib import Path
from io import BytesIO
from urllib.parse import urljoin
import re

# Referenzbild
ref_path = Path('data/reference_images/pregarten.jpg')
ref_img = Image.open(ref_path)
ref_hash = imagehash.phash(ref_img, hash_size=16)

print("=" * 60)
print("REFERENZBILD")
print("=" * 60)
print(f"Größe: {ref_img.size}")
print(f"pHash: {ref_hash}")

def check_image(url, ref_hash):
    """Download und Hash-Check"""
    try:
        resp = requests.get(url, timeout=10, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0'
        })
        if resp.status_code == 200 and len(resp.content) > 1000:
            img = Image.open(BytesIO(resp.content))
            h = imagehash.phash(img, hash_size=16)
            distance = ref_hash - h
            return {
                'size': img.size,
                'hash': str(h),
                'distance': distance,
                'similarity': 1 - (distance / 256)
            }
    except:
        pass
    return None

print("\n" + "=" * 60)
print("SUCHE AUF MEHREREN SEITEN")
print("=" * 60)

pages_to_check = [
    'https://www.muehlviertel.at/',
    'https://www.muehlviertel.at/unsere-region/unsere-gemeinden/pregarten.html',
    'https://www.muehlviertel.at/en/our-region/our-communities/pregarten.html',
    'https://www.muehlviertel.at/unsere-region/unsere-gemeinden.html',
]

all_image_urls = set()

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()

    for page_url in pages_to_check:
        print(f"\n--- {page_url[:60]}... ---")
        try:
            page.goto(page_url, timeout=20000, wait_until='domcontentloaded')
            page.wait_for_timeout(1000)

            # Alle img src + srcset + data-src sammeln
            images = page.evaluate("""() => {
                const urls = new Set();

                document.querySelectorAll('img').forEach(img => {
                    if (img.src) urls.add(img.src);
                    if (img.currentSrc) urls.add(img.currentSrc);
                    if (img.dataset.src) urls.add(img.dataset.src);

                    // srcset parsen
                    if (img.srcset) {
                        img.srcset.split(',').forEach(s => {
                            const url = s.trim().split(' ')[0];
                            if (url) urls.add(url);
                        });
                    }
                });

                // Auch background-images
                document.querySelectorAll('[style*="background"]').forEach(el => {
                    const match = el.style.backgroundImage.match(/url\\(['\"]?([^'\"\\)]+)['\"]?\\)/);
                    if (match) urls.add(match[1]);
                });

                return Array.from(urls);
            }""")

            print(f"  {len(images)} Bild-URLs gefunden")
            all_image_urls.update(images)

        except Exception as e:
            print(f"  Fehler: {e}")

    browser.close()

print(f"\n\nGesamt: {len(all_image_urls)} unique URLs")

# Jetzt alle URLs prüfen die "pregarten" oder ähnliches enthalten
print("\n" + "=" * 60)
print("PRÜFE BILDER MIT 'pregarten' IM NAMEN")
print("=" * 60)

pregarten_urls = [u for u in all_image_urls if 'pregarten' in u.lower()]
print(f"\n{len(pregarten_urls)} URLs mit 'pregarten':")

for url in pregarten_urls:
    print(f"\n{url}")
    result = check_image(url, ref_hash)
    if result:
        print(f"  Größe: {result['size']}, Distanz: {result['distance']}, Similarity: {result['similarity']:.1%}")
        if result['distance'] <= 15:
            print("  >>> MATCH! <<<")

# Auch original/unprocessed Versionen suchen
print("\n" + "=" * 60)
print("SUCHE ORIGINAL-VERSIONEN (ohne _processed_)")
print("=" * 60)

# Versuche original URLs zu konstruieren
for url in list(all_image_urls)[:50]:
    if '_processed_' in url:
        # Original URL konstruieren
        # z.B. /fileadmin/_processed_/d/6/csm_HotelGuglwald... -> /fileadmin/user_upload/...
        original_candidates = [
            re.sub(r'/_processed_/[a-z0-9]/[a-z0-9]/', '/user_upload/', url),
            re.sub(r'csm_', '', url),
        ]

        for orig_url in original_candidates:
            if orig_url not in all_image_urls:
                result = check_image(orig_url, ref_hash)
                if result and result['distance'] <= 50:
                    print(f"\nOriginal gefunden: {orig_url}")
                    print(f"  Größe: {result['size']}, Distanz: {result['distance']}")

print("\n" + "=" * 60)
print("FERTIG")
print("=" * 60)
