"""
Test-Skript für Playwright - Testet die drei Beispielseiten
"""
import json
from playwright.sync_api import sync_playwright
from pathlib import Path


def load_test_sites():
    """Lädt die Testseiten aus der JSON-Datei."""
    with open("data/urls/test_sites.json", "r") as f:
        return json.load(f)


def run_tests():
    """Führt die Playwright-Tests durch."""
    sites = load_test_sites()
    screenshots_dir = Path("output/screenshots")
    screenshots_dir.mkdir(parents=True, exist_ok=True)

    results = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page(viewport={"width": 1280, "height": 720})

        for site in sites:
            print(f"\n{'='*50}")
            print(f"Teste: {site['name']} ({site['url']})")
            print('='*50)

            result = {
                "name": site["name"],
                "url": site["url"],
                "success": False,
                "title": None,
                "screenshot": None,
                "error": None
            }

            try:
                # Seite laden
                page.goto(site["url"], wait_until="networkidle", timeout=30000)
                result["title"] = page.title()
                print(f"✓ Seite geladen - Titel: {result['title']}")

                # Screenshot erstellen
                screenshot_path = screenshots_dir / f"{site['name'].lower()}_screenshot.png"
                page.screenshot(path=str(screenshot_path), full_page=False)
                result["screenshot"] = str(screenshot_path)
                print(f"✓ Screenshot gespeichert: {screenshot_path}")

                # Referenzbild prüfen
                ref_image = Path("data/reference_images") / site["reference_image"]
                if ref_image.exists():
                    print(f"✓ Referenzbild vorhanden: {ref_image}")
                else:
                    print(f"⚠ Kein Referenzbild: {ref_image}")

                result["success"] = True

            except Exception as e:
                result["error"] = str(e)
                print(f"✗ Fehler: {e}")

            results.append(result)

        browser.close()

    # Zusammenfassung
    print(f"\n{'='*50}")
    print("ZUSAMMENFASSUNG")
    print('='*50)

    success_count = sum(1 for r in results if r["success"])
    print(f"Erfolgreich: {success_count}/{len(results)}")

    for r in results:
        status = "✓" if r["success"] else "✗"
        print(f"  {status} {r['name']}: {r['title'] or r['error']}")

    return results


if __name__ == "__main__":
    run_tests()
