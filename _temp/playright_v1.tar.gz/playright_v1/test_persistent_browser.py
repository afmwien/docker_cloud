"""
Test für den Persistent Browser - Zeigt wie Cookies über Neustarts erhalten bleiben
"""
import sys
sys.path.insert(0, ".")

from pathlib import Path
from src.browser import PersistentBrowser, BrowserConfig
from src.cookie_handler import CookieHandler, CookieHandlerConfig


def test_persistent_cookies():
    """Testet ob Cookies nach einem Neustart erhalten bleiben."""

    profile_dir = Path("data/chrome_profile")
    url = "https://www.google.com"

    print("=" * 60)
    print("PERSISTENT BROWSER TEST")
    print("=" * 60)
    print(f"\nProfil-Verzeichnis: {profile_dir.absolute()}")

    # =========================================================================
    # ERSTER DURCHLAUF - Cookies akzeptieren
    # =========================================================================
    print("\n" + "-" * 60)
    print("DURCHLAUF 1: Cookie-Banner akzeptieren")
    print("-" * 60)

    config = BrowserConfig(
        user_data_dir=profile_dir,
        headless=True,
    )

    with PersistentBrowser(config) as browser:
        page = browser.new_page()

        # Cookies vor dem Besuch
        cookies_before = browser.get_cookies()
        print(f"\nCookies vor dem Besuch: {len(cookies_before)}")

        # Seite laden
        print(f"Lade: {url}")
        page.goto(url, wait_until="networkidle")
        page.wait_for_timeout(2000)

        # Cookie-Handler ausführen
        handler = CookieHandler(page, CookieHandlerConfig())
        result = handler.handle_consent()

        print(f"Banner gefunden: {result.banner_found}")
        print(f"Aktion: {result.action_taken}")

        # Cookies nach Consent
        cookies_after = browser.get_cookies()
        print(f"Cookies nach Consent: {len(cookies_after)}")

        # Cookie-Namen anzeigen
        print("\nAktuelle Cookies:")
        for cookie in cookies_after[:10]:
            print(f"  - {cookie['name']}: {cookie['value'][:30]}...")

        # Screenshot
        page.screenshot(path="output/screenshots/persistent_test_1.png")
        print("\nScreenshot: output/screenshots/persistent_test_1.png")

        profile_size = browser.get_profile_size_mb()

    print(f"\nProfil-Größe: {profile_size:.2f} MB")
    print("\n>>> Browser geschlossen - Cookies sind im Profil gespeichert <<<")

    # =========================================================================
    # ZWEITER DURCHLAUF - Cookies sollten noch da sein
    # =========================================================================
    print("\n" + "-" * 60)
    print("DURCHLAUF 2: Browser neu starten - Cookies prüfen")
    print("-" * 60)

    with PersistentBrowser(config) as browser:
        page = browser.new_page()

        # Cookies sollten noch da sein!
        cookies_loaded = browser.get_cookies()
        print(f"\nCookies nach Neustart: {len(cookies_loaded)}")

        if len(cookies_loaded) > 0:
            print("✓ Cookies wurden persistent gespeichert!")
            print("\nGeladene Cookies:")
            for cookie in cookies_loaded[:10]:
                print(f"  - {cookie['name']}")
        else:
            print("✗ Keine Cookies gefunden")

        # Seite laden - Banner sollte nicht mehr erscheinen
        print(f"\nLade erneut: {url}")
        page.goto(url, wait_until="networkidle")
        page.wait_for_timeout(2000)

        # Cookie-Handler prüfen
        handler = CookieHandler(page, CookieHandlerConfig())
        result = handler.handle_consent()

        print(f"Banner gefunden: {result.banner_found}")

        if not result.banner_found:
            print("✓ Kein Cookie-Banner - Consent wurde gespeichert!")
        else:
            print("⚠ Banner noch sichtbar")

        # Screenshot
        page.screenshot(path="output/screenshots/persistent_test_2.png")
        print("\nScreenshot: output/screenshots/persistent_test_2.png")

    # =========================================================================
    # ZUSAMMENFASSUNG
    # =========================================================================
    print("\n" + "=" * 60)
    print("ZUSAMMENFASSUNG")
    print("=" * 60)
    print(f"\nProfil-Verzeichnis: {profile_dir.absolute()}")
    print(f"Profil-Größe: {profile_size:.2f} MB")
    print(f"Cookies geladen: {len(cookies_loaded)}")
    print("\nDas Profil bleibt erhalten und kann wiederverwendet werden.")
    print("Um das Profil zu löschen: browser.reset_profile()")


if __name__ == "__main__":
    test_persistent_cookies()
