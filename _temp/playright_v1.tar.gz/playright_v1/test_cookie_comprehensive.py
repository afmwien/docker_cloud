"""
Vollständiger Cookie Handler Test mit allen Features
"""
import sys
import json
from pathlib import Path
sys.path.insert(0, ".")

from playwright.sync_api import sync_playwright
from src.cookie_handler import CookieHandler, CookieHandlerConfig, ConsentAction
from src.browser import get_stealth_context_options, apply_stealth_settings


def run_comprehensive_test():
    """Umfassender Test des Cookie Handlers."""

    # Test-Seiten (verschiedene CMPs)
    test_sites = [
        {
            "url": "https://www.thermen-installateur.at/",
            "name": "Thermen-Installateur",
            "expected_banner": False,
        },
        {
            "url": "https://www.google.com",
            "name": "Google",
            "expected_banner": True,  # Google zeigt manchmal einen Banner
        },
        {
            "url": "https://www.wikipedia.org",
            "name": "Wikipedia",
            "expected_banner": False,
        },
        {
            "url": "https://github.com",
            "name": "GitHub",
            "expected_banner": False,
        },
    ]

    results = []
    output_dir = Path("output/cookie_test")
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("UMFASSENDER COOKIE HANDLER TEST")
    print("=" * 70)

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(**get_stealth_context_options())

        for site in test_sites:
            print(f"\n{'─' * 70}")
            print(f"TESTE: {site['name']} ({site['url']})")
            print("─" * 70)

            page = context.new_page()
            apply_stealth_settings(page)

            site_result = {
                "name": site["name"],
                "url": site["url"],
                "expected_banner": site["expected_banner"],
            }

            try:
                # Seite laden
                page.goto(site["url"], wait_until="networkidle", timeout=30000)

                # Kurz warten für dynamische Banner
                page.wait_for_timeout(2000)

                # Screenshot vorher
                before_path = output_dir / f"{site['name'].lower()}_before.png"
                page.screenshot(path=str(before_path))
                print(f"  Screenshot vorher: {before_path}")

                # Cookie Handler ausführen
                config = CookieHandlerConfig(
                    detection_timeout_ms=5000,
                    click_timeout_ms=3000,
                    retry_attempts=3,
                    check_shadow_dom=True,
                    check_iframes=True,
                    save_storage_state=True,
                    take_debug_screenshots=True,
                )

                handler = CookieHandler(page, config)
                result = handler.handle_consent()

                # Ergebnisse speichern
                site_result.update({
                    "success": result.success,
                    "banner_found": result.banner_found,
                    "cmp_detected": result.cmp_detected,
                    "method_used": result.method_used,
                    "selector_used": result.selector_used,
                    "action_taken": result.action_taken,
                    "duration_ms": result.duration_ms,
                    "cookies_before": result.cookies_before,
                    "cookies_after": result.cookies_after,
                    "error": result.error,
                })

                # Ausgabe
                print(f"  Banner gefunden:  {result.banner_found}")
                print(f"  CMP erkannt:      {result.cmp_detected or '-'}")
                print(f"  Erfolgreich:      {result.success}")
                print(f"  Methode:          {result.method_used or '-'}")
                print(f"  Selektor:         {result.selector_used or '-'}")
                print(f"  Cookies:          {result.cookies_before} → {result.cookies_after}")
                print(f"  Dauer:            {result.duration_ms:.0f}ms")

                # Screenshot nachher
                page.wait_for_timeout(1000)
                after_path = output_dir / f"{site['name'].lower()}_after.png"
                page.screenshot(path=str(after_path))
                print(f"  Screenshot nachher: {after_path}")

            except Exception as e:
                site_result["error"] = str(e)
                print(f"  FEHLER: {e}")

            finally:
                page.close()

            results.append(site_result)

        context.close()
        browser.close()

    # Zusammenfassung
    print("\n" + "=" * 70)
    print("ZUSAMMENFASSUNG")
    print("=" * 70)

    total = len(results)
    success = sum(1 for r in results if r.get("success", False))
    banners_found = sum(1 for r in results if r.get("banner_found", False))

    print(f"\nGetestet:        {total} Seiten")
    print(f"Erfolgreich:     {success}/{total}")
    print(f"Banner gefunden: {banners_found}")

    print("\nDetails:")
    for r in results:
        status = "✓" if r.get("success") else "✗"
        banner = "🍪" if r.get("banner_found") else "  "
        print(f"  {status} {banner} {r['name']}: {r.get('action_taken', r.get('error', 'unbekannt'))}")

    # Ergebnisse als JSON speichern
    json_path = output_dir / "test_results.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"\nErgebnisse gespeichert: {json_path}")

    return results


if __name__ == "__main__":
    run_comprehensive_test()
